﻿namespace EmpolyeePerformanceTracker
{
    partial class BagoAplaya
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            returnButton = new Button();
            DataGridViewBagoAplaya = new DataGridView();
            txtEmployeeName = new TextBox();
            EMPLONAM = new Label();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtDaysWorked = new TextBox();
            txtTotalTimeSlacked = new TextBox();
            txtGrade = new TextBox();
            btnEmployeeAdd = new Button();
            label4 = new Label();
            txtDaysAbsent = new TextBox();
            btnDelete = new Button();
            lblEmployeeID = new Label();
            txtEmployeeID = new TextBox();
            ((System.ComponentModel.ISupportInitialize)DataGridViewBagoAplaya).BeginInit();
            SuspendLayout();
            // 
            // returnButton
            // 
            returnButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            returnButton.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Italic, GraphicsUnit.Point);
            returnButton.Location = new Point(532, 13);
            returnButton.Margin = new Padding(3, 4, 3, 4);
            returnButton.Name = "returnButton";
            returnButton.Size = new Size(113, 41);
            returnButton.TabIndex = 5;
            returnButton.Text = "Return";
            returnButton.UseVisualStyleBackColor = true;
            returnButton.Click += returnButton_Click;
            // 
            // DataGridViewBagoAplaya
            // 
            DataGridViewBagoAplaya.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            DataGridViewBagoAplaya.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataGridViewBagoAplaya.Location = new Point(32, 95);
            DataGridViewBagoAplaya.Name = "DataGridViewBagoAplaya";
            DataGridViewBagoAplaya.RowTemplate.Height = 28;
            DataGridViewBagoAplaya.Size = new Size(613, 252);
            DataGridViewBagoAplaya.TabIndex = 6;
            DataGridViewBagoAplaya.CellClick += DataGridViewBagoAplaya_CellClick;
            DataGridViewBagoAplaya.CellContentClick += dataGridView1_CellContentClick;
            // 
            // txtEmployeeName
            // 
            txtEmployeeName.Location = new Point(32, 436);
            txtEmployeeName.Name = "txtEmployeeName";
            txtEmployeeName.Size = new Size(272, 26);
            txtEmployeeName.TabIndex = 8;
            // 
            // EMPLONAM
            // 
            EMPLONAM.AutoSize = true;
            EMPLONAM.Location = new Point(32, 414);
            EMPLONAM.Name = "EMPLONAM";
            EMPLONAM.Size = new Size(108, 19);
            EMPLONAM.TabIndex = 9;
            EMPLONAM.Text = "Employee Name";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(32, 465);
            label1.Name = "label1";
            label1.Size = new Size(90, 19);
            label1.TabIndex = 10;
            label1.Text = "Days Worked";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(32, 567);
            label2.Name = "label2";
            label2.Size = new Size(140, 19);
            label2.TabIndex = 11;
            label2.Text = "Total Time Slacked off";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(32, 618);
            label3.Name = "label3";
            label3.Size = new Size(46, 19);
            label3.TabIndex = 12;
            label3.Text = "Grade";
            // 
            // txtDaysWorked
            // 
            txtDaysWorked.Location = new Point(32, 487);
            txtDaysWorked.Name = "txtDaysWorked";
            txtDaysWorked.Size = new Size(272, 26);
            txtDaysWorked.TabIndex = 13;
            // 
            // txtTotalTimeSlacked
            // 
            txtTotalTimeSlacked.Location = new Point(32, 589);
            txtTotalTimeSlacked.Name = "txtTotalTimeSlacked";
            txtTotalTimeSlacked.Size = new Size(272, 26);
            txtTotalTimeSlacked.TabIndex = 14;
            // 
            // txtGrade
            // 
            txtGrade.Location = new Point(32, 640);
            txtGrade.Name = "txtGrade";
            txtGrade.Size = new Size(272, 26);
            txtGrade.TabIndex = 15;
            // 
            // btnEmployeeAdd
            // 
            btnEmployeeAdd.Location = new Point(32, 686);
            btnEmployeeAdd.Name = "btnEmployeeAdd";
            btnEmployeeAdd.Size = new Size(90, 36);
            btnEmployeeAdd.TabIndex = 16;
            btnEmployeeAdd.Text = "Add";
            btnEmployeeAdd.UseVisualStyleBackColor = true;
            btnEmployeeAdd.Click += btnEmployeeAdd_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(32, 516);
            label4.Name = "label4";
            label4.Size = new Size(86, 19);
            label4.TabIndex = 17;
            label4.Text = "Days Absent";
            // 
            // txtDaysAbsent
            // 
            txtDaysAbsent.Location = new Point(32, 540);
            txtDaysAbsent.Name = "txtDaysAbsent";
            txtDaysAbsent.Size = new Size(272, 26);
            txtDaysAbsent.TabIndex = 18;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(128, 686);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(90, 36);
            btnDelete.TabIndex = 19;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // lblEmployeeID
            // 
            lblEmployeeID.AutoSize = true;
            lblEmployeeID.Location = new Point(32, 363);
            lblEmployeeID.Name = "lblEmployeeID";
            lblEmployeeID.Size = new Size(82, 19);
            lblEmployeeID.TabIndex = 21;
            lblEmployeeID.Text = "EmployeeID";
            // 
            // txtEmployeeID
            // 
            txtEmployeeID.Location = new Point(32, 385);
            txtEmployeeID.Name = "txtEmployeeID";
            txtEmployeeID.Size = new Size(272, 26);
            txtEmployeeID.TabIndex = 20;
            txtEmployeeID.TextChanged += txtEmployeeID_TextChanged;
            // 
            // BagoAplaya
            // 
            AutoScaleDimensions = new SizeF(8F, 19F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Orange;
            ClientSize = new Size(663, 775);
            Controls.Add(lblEmployeeID);
            Controls.Add(txtEmployeeID);
            Controls.Add(btnDelete);
            Controls.Add(txtDaysAbsent);
            Controls.Add(label4);
            Controls.Add(btnEmployeeAdd);
            Controls.Add(txtGrade);
            Controls.Add(txtTotalTimeSlacked);
            Controls.Add(txtDaysWorked);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(EMPLONAM);
            Controls.Add(txtEmployeeName);
            Controls.Add(DataGridViewBagoAplaya);
            Controls.Add(returnButton);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Margin = new Padding(3, 4, 3, 4);
            Name = "BagoAplaya";
            Text = "BagoAplaya";
            Load += BagoAplaya_Load;
            ((System.ComponentModel.ISupportInitialize)DataGridViewBagoAplaya).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button returnButton;
        private Button scheduleButton;
        private Button EmployeeList;
        private DataGridView DataGridViewBagoAplaya;
        private TextBox txtEmployeeName;
        private Label EMPLONAM;
        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtDaysWorked;
        private TextBox txtTotalTimeSlacked;
        private TextBox txtGrade;
        private Button btnEmployeeAdd;
        private Label label4;
        private TextBox txtDaysAbsent;
        private Button btnDelete;
        private Label lblEmployeeID;
        private TextBox txtEmployeeID;
    }
}