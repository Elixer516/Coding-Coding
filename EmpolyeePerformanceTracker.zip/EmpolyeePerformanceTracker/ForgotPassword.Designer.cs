﻿namespace EmpolyeePerformanceTracker
{
    partial class ForgotPassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ForgotPasswordLabel = new Label();
            OldPasswordTextBox = new TextBox();
            NewPasswordLabel = new Label();
            NewPasswordTextBox = new TextBox();
            ResetPasswordButton = new Button();
            SuspendLayout();
            // 
            // ForgotPasswordLabel
            // 
            ForgotPasswordLabel.AutoSize = true;
            ForgotPasswordLabel.BackColor = Color.Snow;
            ForgotPasswordLabel.Font = new Font("Sitka Heading", 12F, FontStyle.Italic, GraphicsUnit.Point);
            ForgotPasswordLabel.Location = new Point(48, 57);
            ForgotPasswordLabel.Name = "ForgotPasswordLabel";
            ForgotPasswordLabel.Size = new Size(105, 23);
            ForgotPasswordLabel.TabIndex = 0;
            ForgotPasswordLabel.Text = "Old Password:";
            // 
            // OldPasswordTextBox
            // 
            OldPasswordTextBox.Location = new Point(164, 57);
            OldPasswordTextBox.Name = "OldPasswordTextBox";
            OldPasswordTextBox.Size = new Size(118, 23);
            OldPasswordTextBox.TabIndex = 1;
            // 
            // NewPasswordLabel
            // 
            NewPasswordLabel.AutoSize = true;
            NewPasswordLabel.BackColor = Color.Snow;
            NewPasswordLabel.Font = new Font("Sitka Heading", 12F, FontStyle.Italic, GraphicsUnit.Point);
            NewPasswordLabel.Location = new Point(45, 111);
            NewPasswordLabel.Name = "NewPasswordLabel";
            NewPasswordLabel.Size = new Size(113, 23);
            NewPasswordLabel.TabIndex = 2;
            NewPasswordLabel.Text = "New Password:";
            NewPasswordLabel.Click += label1_Click;
            // 
            // NewPasswordTextBox
            // 
            NewPasswordTextBox.Location = new Point(164, 111);
            NewPasswordTextBox.Name = "NewPasswordTextBox";
            NewPasswordTextBox.Size = new Size(124, 23);
            NewPasswordTextBox.TabIndex = 3;
            NewPasswordTextBox.TextChanged += NewPasswordTextBox_TextChanged;
            // 
            // ResetPasswordButton
            // 
            ResetPasswordButton.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            ResetPasswordButton.Location = new Point(280, 142);
            ResetPasswordButton.Name = "ResetPasswordButton";
            ResetPasswordButton.Size = new Size(121, 23);
            ResetPasswordButton.TabIndex = 4;
            ResetPasswordButton.Text = "Reset Password";
            ResetPasswordButton.UseVisualStyleBackColor = true;
            ResetPasswordButton.Click += ResetPasswordButton_Click;
            // 
            // ForgotPassword
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Orange;
            ClientSize = new Size(413, 177);
            Controls.Add(ResetPasswordButton);
            Controls.Add(NewPasswordTextBox);
            Controls.Add(NewPasswordLabel);
            Controls.Add(OldPasswordTextBox);
            Controls.Add(ForgotPasswordLabel);
            Name = "ForgotPassword";
            Text = "ForgotPassword";
            Load += ForgotPassword_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label ForgotPasswordLabel;
        private TextBox OldPasswordTextBox;
        private Label NewPasswordLabel;
        private TextBox NewPasswordTextBox;
        private Button ResetPasswordButton;
    }
}