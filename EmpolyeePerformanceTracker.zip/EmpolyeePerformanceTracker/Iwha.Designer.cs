﻿namespace EmpolyeePerformanceTracker
{
    partial class Iwha
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            returnButton = new Button();
            DataGridViewIwha = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)DataGridViewIwha).BeginInit();
            SuspendLayout();
            // 
            // returnButton
            // 
            returnButton.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point);
            returnButton.Location = new Point(12, 23);
            returnButton.Margin = new Padding(3, 4, 3, 4);
            returnButton.Name = "returnButton";
            returnButton.Size = new Size(115, 42);
            returnButton.TabIndex = 5;
            returnButton.Text = "Return";
            returnButton.UseVisualStyleBackColor = true;
            returnButton.Click += returnButton_Click;
            // 
            // DataGridViewIwha
            // 
            DataGridViewIwha.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            DataGridViewIwha.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataGridViewIwha.Location = new Point(12, 83);
            DataGridViewIwha.Name = "DataGridViewIwha";
            DataGridViewIwha.RowTemplate.Height = 28;
            DataGridViewIwha.Size = new Size(553, 221);
            DataGridViewIwha.TabIndex = 6;
            DataGridViewIwha.CellContentClick += DataGridViewIwha_CellContentClick;
            // 
            // Iwha
            // 
            AutoScaleDimensions = new SizeF(8F, 19F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Orange;
            ClientSize = new Size(577, 405);
            Controls.Add(DataGridViewIwha);
            Controls.Add(returnButton);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Margin = new Padding(3, 4, 3, 4);
            Name = "Iwha";
            Text = "Iwha";
            ((System.ComponentModel.ISupportInitialize)DataGridViewIwha).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button returnButton;
        private DataGridView DataGridViewIwha;
    }
}