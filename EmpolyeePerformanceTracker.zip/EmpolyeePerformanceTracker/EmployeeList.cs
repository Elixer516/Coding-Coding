﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmpolyeePerformanceTracker
{
    public partial class EmployeeList : Form
    {
        private Branches _BranchesForm;
        public EmployeeList(Branches branchesForm)
        {
            InitializeComponent();
            _BranchesForm = branchesForm;
        }

        private void returnButton_Click(object sender, EventArgs e)
        {
            this.Close();
            _BranchesForm.Show();
        }

        private void EmployeeList_Load(object sender, EventArgs e)
        {

        }
    }
}
