﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpolyeePerformanceTracker.Models
{
    internal class BangkalModel
    {
        public int id { get; set; }
        public string EmployeeName { get; set; }
        public int DaysWorked { get; set; }

        public int DaysAbsent { get; set; }

        public string TotalTimeSlacked { get; set; }

        public string Grade {  get; set; }
       
    }
}
