﻿namespace EmpolyeePerformanceTracker
{
    partial class Lobby
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            AdminLabel = new Label();
            branchesButton = new Button();
            button2 = new Button();
            LogoutButton = new Button();
            SuspendLayout();
            // 
            // AdminLabel
            // 
            AdminLabel.Location = new Point(0, 0);
            AdminLabel.Name = "AdminLabel";
            AdminLabel.Size = new Size(114, 29);
            AdminLabel.TabIndex = 4;
            // 
            // branchesButton
            // 
            branchesButton.Font = new Font("Sitka Heading", 12F, FontStyle.Italic, GraphicsUnit.Point);
            branchesButton.Location = new Point(14, 46);
            branchesButton.Margin = new Padding(3, 4, 3, 4);
            branchesButton.Name = "branchesButton";
            branchesButton.Size = new Size(103, 38);
            branchesButton.TabIndex = 1;
            branchesButton.Text = "Branches";
            branchesButton.UseVisualStyleBackColor = true;
            branchesButton.Click += branchesButton_Click;
            // 
            // button2
            // 
            button2.Font = new Font("Sitka Heading", 12F, FontStyle.Italic, GraphicsUnit.Point);
            button2.Location = new Point(14, 101);
            button2.Margin = new Padding(3, 4, 3, 4);
            button2.Name = "button2";
            button2.Size = new Size(103, 41);
            button2.TabIndex = 2;
            button2.Text = "Settings";
            button2.UseVisualStyleBackColor = true;
            // 
            // LogoutButton
            // 
            LogoutButton.Font = new Font("Sitka Heading", 12F, FontStyle.Italic, GraphicsUnit.Point);
            LogoutButton.Location = new Point(14, 149);
            LogoutButton.Margin = new Padding(3, 4, 3, 4);
            LogoutButton.Name = "LogoutButton";
            LogoutButton.Size = new Size(103, 42);
            LogoutButton.TabIndex = 3;
            LogoutButton.Text = "Logout";
            LogoutButton.UseVisualStyleBackColor = true;
            LogoutButton.Click += LogoutButton_Click;
            // 
            // Lobby
            // 
            AutoScaleDimensions = new SizeF(8F, 19F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Orange;
            ClientSize = new Size(440, 294);
            Controls.Add(LogoutButton);
            Controls.Add(button2);
            Controls.Add(branchesButton);
            Controls.Add(AdminLabel);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Lobby";
            Text = "Lobby";
            Load += Lobby_Load;
            ResumeLayout(false);
        }

        #endregion

        private Label AdminLabel;
        private Button branchesButton;
        private Button button2;
        private Button LogoutButton;
        private DataGridView dataGridView1;
    }
}