﻿using EmpolyeePerformanceTracker.ModelViews;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmpolyeePerformanceTracker
{
    public partial class MatinaAplaya : Form
    {
        private MatinaAplayaMV matinaaplayaMV;

        private Branches _branchForm;
        public MatinaAplaya(Branches branchForm)
        {
            InitializeComponent();
            _branchForm = branchForm;
            matinaaplayaMV = new MatinaAplayaMV();
            LoadData();
        }

        private void LoadData()
        {
            DataGridViewMatinaAplaya.DataSource = null;
            DataGridViewMatinaAplaya.DataSource = matinaaplayaMV.MatinaAplaya;
        }

        private void EmployeeList_Click(object sender, EventArgs e)
        {
            EmployeeList nextForm = new EmployeeList(_branchForm);
            nextForm.Show();
            this.Hide();
        }

        private void returnButton_Click(object sender, EventArgs e)
        {
            _branchForm.Show();
            this.Close();
        }

        private void MatinaAplaya_Load(object sender, EventArgs e)
        {

        }

        private void DataGridViewMatinaAplaya_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
