﻿namespace EmpolyeePerformanceTracker
{
    partial class Bangkal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            returnButton = new Button();
            DataGridViewBangkal = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)DataGridViewBangkal).BeginInit();
            SuspendLayout();
            // 
            // returnButton
            // 
            returnButton.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            returnButton.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point);
            returnButton.Location = new Point(34, 22);
            returnButton.Margin = new Padding(3, 4, 3, 4);
            returnButton.Name = "returnButton";
            returnButton.Size = new Size(115, 39);
            returnButton.TabIndex = 5;
            returnButton.Text = "Return";
            returnButton.UseVisualStyleBackColor = true;
            returnButton.Click += returnButton_Click;
            // 
            // DataGridViewBangkal
            // 
            DataGridViewBangkal.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            DataGridViewBangkal.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DataGridViewBangkal.BackgroundColor = Color.Orange;
            DataGridViewBangkal.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataGridViewBangkal.GridColor = SystemColors.ControlDarkDark;
            DataGridViewBangkal.Location = new Point(38, 68);
            DataGridViewBangkal.Name = "DataGridViewBangkal";
            DataGridViewBangkal.RowTemplate.Height = 28;
            DataGridViewBangkal.Size = new Size(622, 173);
            DataGridViewBangkal.TabIndex = 6;
            DataGridViewBangkal.CellContentClick += dataGridView1_CellContentClick;
            // 
            // Bangkal
            // 
            AutoScaleDimensions = new SizeF(8F, 19F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Orange;
            ClientSize = new Size(685, 619);
            Controls.Add(DataGridViewBangkal);
            Controls.Add(returnButton);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Margin = new Padding(3, 4, 3, 4);
            Name = "Bangkal";
            Text = "Bangkal";
            ((System.ComponentModel.ISupportInitialize)DataGridViewBangkal).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button returnButton;
        private DataGridView DataGridViewBangkal;
    }
}