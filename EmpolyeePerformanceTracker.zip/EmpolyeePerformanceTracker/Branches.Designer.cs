﻿namespace EmpolyeePerformanceTracker
{
    partial class Branches
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BranchLabel = new Label();
            MatinaAplayaButton = new Button();
            returnButton = new Button();
            bangkalButton = new Button();
            iwhaButton = new Button();
            BagoAplayaButton = new Button();
            PequenoButton = new Button();
            SuspendLayout();
            // 
            // BranchLabel
            // 
            BranchLabel.AutoSize = true;
            BranchLabel.BackColor = Color.White;
            BranchLabel.Font = new Font("Sitka Banner", 15.7499981F, FontStyle.Bold, GraphicsUnit.Point);
            BranchLabel.Location = new Point(31, 14);
            BranchLabel.Name = "BranchLabel";
            BranchLabel.Size = new Size(92, 30);
            BranchLabel.TabIndex = 0;
            BranchLabel.Text = "Branches";
            // 
            // MatinaAplayaButton
            // 
            MatinaAplayaButton.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Italic, GraphicsUnit.Point);
            MatinaAplayaButton.Location = new Point(44, 72);
            MatinaAplayaButton.Name = "MatinaAplayaButton";
            MatinaAplayaButton.Size = new Size(121, 36);
            MatinaAplayaButton.TabIndex = 1;
            MatinaAplayaButton.Text = "Matina Aplaya";
            MatinaAplayaButton.UseVisualStyleBackColor = true;
            MatinaAplayaButton.Click += MatinaAplayaButton_Click;
            // 
            // returnButton
            // 
            returnButton.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point);
            returnButton.Location = new Point(323, 10);
            returnButton.Name = "returnButton";
            returnButton.Size = new Size(87, 32);
            returnButton.TabIndex = 2;
            returnButton.Text = "Return";
            returnButton.UseVisualStyleBackColor = true;
            returnButton.Click += returnButton_Click;
            // 
            // bangkalButton
            // 
            bangkalButton.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Italic, GraphicsUnit.Point);
            bangkalButton.Location = new Point(217, 47);
            bangkalButton.Name = "bangkalButton";
            bangkalButton.Size = new Size(104, 36);
            bangkalButton.TabIndex = 3;
            bangkalButton.Text = "Bangkal";
            bangkalButton.UseVisualStyleBackColor = true;
            bangkalButton.Click += bangkalButton_Click;
            // 
            // iwhaButton
            // 
            iwhaButton.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Italic, GraphicsUnit.Point);
            iwhaButton.Location = new Point(220, 99);
            iwhaButton.Name = "iwhaButton";
            iwhaButton.Size = new Size(101, 30);
            iwhaButton.TabIndex = 4;
            iwhaButton.Text = "Iwha";
            iwhaButton.UseVisualStyleBackColor = true;
            iwhaButton.Click += iwhaButton_Click;
            // 
            // BagoAplayaButton
            // 
            BagoAplayaButton.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Italic, GraphicsUnit.Point);
            BagoAplayaButton.Location = new Point(44, 130);
            BagoAplayaButton.Name = "BagoAplayaButton";
            BagoAplayaButton.Size = new Size(121, 33);
            BagoAplayaButton.TabIndex = 5;
            BagoAplayaButton.Text = "Bago Aplaya";
            BagoAplayaButton.UseVisualStyleBackColor = true;
            BagoAplayaButton.Click += BagoAplayaButton_Click;
            // 
            // PequenoButton
            // 
            PequenoButton.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Italic, GraphicsUnit.Point);
            PequenoButton.Location = new Point(220, 145);
            PequenoButton.Name = "PequenoButton";
            PequenoButton.Size = new Size(101, 35);
            PequenoButton.TabIndex = 6;
            PequenoButton.Text = "C. Pequeno";
            PequenoButton.UseVisualStyleBackColor = true;
            PequenoButton.Click += PequenoButton_Click;
            // 
            // Branches
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.Orange;
            ClientSize = new Size(422, 195);
            Controls.Add(PequenoButton);
            Controls.Add(BagoAplayaButton);
            Controls.Add(iwhaButton);
            Controls.Add(bangkalButton);
            Controls.Add(returnButton);
            Controls.Add(MatinaAplayaButton);
            Controls.Add(BranchLabel);
            ForeColor = SystemColors.ControlText;
            Name = "Branches";
            Text = "Branches";
            Load += Branches_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label BranchLabel;
        private Button MatinaAplayaButton;
        private Button returnButton;
        private Button bangkalButton;
        private Button iwhaButton;
        private Button BagoAplayaButton;
        private Button PequenoButton;
    }
}