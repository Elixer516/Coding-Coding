﻿using EmpolyeePerformanceTracker.Model;
using EmpolyeePerformanceTracker.ModelViews;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmpolyeePerformanceTracker
{


    public partial class BagoAplaya : Form
    {
        private BagoAplayaMV bagoaplayaMV;
        private Branches _BranchesForm;
        public BagoAplaya(Branches branchesForm)
        {
            InitializeComponent();
            _BranchesForm = branchesForm;
            bagoaplayaMV = new BagoAplayaMV();
            LoadData();
        }

        private void LoadData()
        {
            DataGridViewBagoAplaya.DataSource = null;
            DataGridViewBagoAplaya.DataSource = bagoaplayaMV.BagoAplaya1;
        }


        private void returnButton_Click(object sender, EventArgs e)
        {
            this.Close();
            _BranchesForm.Show();
        }

        private void EmployeeList_Click(object sender, EventArgs e)
        {
            EmployeeList nextForm = new EmployeeList(_BranchesForm);
            nextForm.Show();
            this.Hide();
        }

        private void BagoAplaya_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void DataGridViewBagoAplaya_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = DataGridViewBagoAplaya.Rows[e.RowIndex];
                txtEmployeeName.Text = row.Cells["EmployeeName"].Value.ToString();
            }
        }

        private void btnEmployeeAdd_Click(object sender, EventArgs e)
        {
            var bagoaplaya = new BagoAplayaModel
            {
                id = int.Parse(txtEmployeeID.Text),
                EmployeeName = txtEmployeeName.Text,
                DaysWorked = int.Parse(txtDaysWorked.Text),
                DaysAbsent = int.Parse(txtDaysAbsent.Text),
                TotalTimeSlacked = txtTotalTimeSlacked.Text,
                Grade = txtGrade.Text,

            };

            bagoaplayaMV.AddEmployee(bagoaplaya);
            LoadData();
            ClearFields();
        }

        private void ClearFields()
        {
            txtEmployeeID.Clear();
            txtEmployeeName.Clear();
            txtDaysWorked.Clear();
            txtDaysAbsent.Clear();
            txtTotalTimeSlacked.Clear();
            txtGrade.Clear();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            {
                if (DataGridViewBagoAplaya.SelectedRows.Count > 0)
                {
                    var selectedRow = DataGridViewBagoAplaya.SelectedRows[0];
                    int id = (int)selectedRow.Cells["id"].Value;

                    bagoaplayaMV.DeleteEmployee(id);
                    LoadData();
                    ClearFields();

                }
            }
        }

        private void txtEmployeeID_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
   
