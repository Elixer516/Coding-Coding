﻿namespace EmpolyeePerformanceTracker
{
    partial class Admin_login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            LoginSign = new Label();
            UsernameLabel = new Label();
            PasswordLabel = new Label();
            UsernameTextBox = new TextBox();
            PasswordTextBox = new TextBox();
            LoginButton = new Button();
            ForgetPassword = new Button();
            SuspendLayout();
            // 
            // LoginSign
            // 
            LoginSign.AutoSize = true;
            LoginSign.BackColor = Color.Linen;
            LoginSign.FlatStyle = FlatStyle.Popup;
            LoginSign.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            LoginSign.Location = new Point(12, 20);
            LoginSign.Name = "LoginSign";
            LoginSign.Size = new Size(110, 28);
            LoginSign.TabIndex = 0;
            LoginSign.Text = "Admin Login";
            // 
            // UsernameLabel
            // 
            UsernameLabel.AutoSize = true;
            UsernameLabel.BackColor = Color.SeaShell;
            UsernameLabel.Font = new Font("Sitka Heading", 14.2499981F, FontStyle.Italic, GraphicsUnit.Point);
            UsernameLabel.Location = new Point(48, 57);
            UsernameLabel.Name = "UsernameLabel";
            UsernameLabel.Size = new Size(97, 28);
            UsernameLabel.TabIndex = 1;
            UsernameLabel.Text = "Username:";
            // 
            // PasswordLabel
            // 
            PasswordLabel.AutoSize = true;
            PasswordLabel.BackColor = Color.Snow;
            PasswordLabel.Font = new Font("Sitka Heading", 14.2499981F, FontStyle.Italic, GraphicsUnit.Point);
            PasswordLabel.Location = new Point(51, 97);
            PasswordLabel.Name = "PasswordLabel";
            PasswordLabel.Size = new Size(94, 28);
            PasswordLabel.TabIndex = 2;
            PasswordLabel.Text = "Password:";
            // 
            // UsernameTextBox
            // 
            UsernameTextBox.Location = new Point(150, 62);
            UsernameTextBox.Name = "UsernameTextBox";
            UsernameTextBox.Size = new Size(147, 23);
            UsernameTextBox.TabIndex = 3;
            // 
            // PasswordTextBox
            // 
            PasswordTextBox.Location = new Point(150, 104);
            PasswordTextBox.Name = "PasswordTextBox";
            PasswordTextBox.Size = new Size(147, 23);
            PasswordTextBox.TabIndex = 4;
            // 
            // LoginButton
            // 
            LoginButton.BackgroundImageLayout = ImageLayout.None;
            LoginButton.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point);
            LoginButton.Location = new Point(183, 133);
            LoginButton.Name = "LoginButton";
            LoginButton.Size = new Size(75, 40);
            LoginButton.TabIndex = 5;
            LoginButton.Text = "Login";
            LoginButton.UseVisualStyleBackColor = true;
            LoginButton.Click += LoginButton_Click;
            // 
            // ForgetPassword
            // 
            ForgetPassword.Font = new Font("Arial Rounded MT Bold", 9F, FontStyle.Regular, GraphicsUnit.Point);
            ForgetPassword.Location = new Point(278, 159);
            ForgetPassword.Name = "ForgetPassword";
            ForgetPassword.Size = new Size(123, 23);
            ForgetPassword.TabIndex = 6;
            ForgetPassword.Text = "Forget Password";
            ForgetPassword.UseVisualStyleBackColor = true;
            ForgetPassword.Click += ForgetPassword_Click;
            // 
            // Admin_login
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Orange;
            ClientSize = new Size(413, 194);
            Controls.Add(ForgetPassword);
            Controls.Add(LoginButton);
            Controls.Add(PasswordTextBox);
            Controls.Add(UsernameTextBox);
            Controls.Add(PasswordLabel);
            Controls.Add(UsernameLabel);
            Controls.Add(LoginSign);
            Name = "Admin_login";
            Text = "Admin_login";
            Load += Admin_login_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label LoginSign;
        private Label UsernameLabel;
        private Label PasswordLabel;
        private TextBox UsernameTextBox;
        private TextBox PasswordTextBox;
        private Button LoginButton;
        private Button ForgetPassword;
    }
}