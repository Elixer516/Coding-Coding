﻿namespace EmpolyeePerformanceTracker
{
    partial class MatinaAplaya
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            returnButton = new Button();
            DataGridViewMatinaAplaya = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)DataGridViewMatinaAplaya).BeginInit();
            SuspendLayout();
            // 
            // returnButton
            // 
            returnButton.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point);
            returnButton.Location = new Point(12, 31);
            returnButton.Margin = new Padding(3, 4, 3, 4);
            returnButton.Name = "returnButton";
            returnButton.Size = new Size(122, 41);
            returnButton.TabIndex = 2;
            returnButton.Text = "Return";
            returnButton.UseVisualStyleBackColor = true;
            returnButton.Click += returnButton_Click;
            // 
            // DataGridViewMatinaAplaya
            // 
            DataGridViewMatinaAplaya.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            DataGridViewMatinaAplaya.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataGridViewMatinaAplaya.Location = new Point(12, 99);
            DataGridViewMatinaAplaya.Name = "DataGridViewMatinaAplaya";
            DataGridViewMatinaAplaya.RowTemplate.Height = 28;
            DataGridViewMatinaAplaya.Size = new Size(638, 254);
            DataGridViewMatinaAplaya.TabIndex = 3;
            DataGridViewMatinaAplaya.CellContentClick += DataGridViewMatinaAplaya_CellContentClick;
            // 
            // MatinaAplaya
            // 
            AutoScaleDimensions = new SizeF(8F, 19F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Orange;
            ClientSize = new Size(662, 433);
            Controls.Add(DataGridViewMatinaAplaya);
            Controls.Add(returnButton);
            Margin = new Padding(3, 4, 3, 4);
            Name = "MatinaAplaya";
            Text = "MatinaAplaya";
            Load += MatinaAplaya_Load;
            ((System.ComponentModel.ISupportInitialize)DataGridViewMatinaAplaya).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private Button returnButton;
        private DataGridView DataGridViewMatinaAplaya;
    }
}