﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace EmpolyeePerformanceTracker
{
    public partial class Admin_login : Form
    {
        public Admin_login()
        {
            InitializeComponent();
            PasswordTextBox.PasswordChar = '*';
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            string username = UsernameTextBox.Text;
            string password = PasswordTextBox.Text;

            if (ValidateCredentials(username, password))

            {
                MessageBox.Show("Login successful!");
                Lobby mainForm = new Lobby();
                mainForm.Show();
                this.Hide();

                UsernameTextBox.Text = "";
                PasswordTextBox.Text = "";
            }
            else
            {
                MessageBox.Show("Invalid username or password.");
            }
        }
        private void PasswordTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
            PasswordTextBox.Text += '*';
        }
        private bool ValidateCredentials(string username, string password)
        {
            string validUsername = "admin";
            string validPassword = "admin123";

            return username == validUsername && password == validPassword;
        }

        private void ForgetPassword_Click(object sender, EventArgs e)
        {
        }

        private void Admin_login_Load(object sender, EventArgs e)
        {

        }
    }
}
