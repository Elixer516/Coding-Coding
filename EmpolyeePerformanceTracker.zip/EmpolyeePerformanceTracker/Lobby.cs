﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmpolyeePerformanceTracker
{
    public partial class Lobby : Form
    {
        private Branches _branchesForm;
        private MatinaAplaya _matinaAplayaForm;
        private BagoAplaya _bagoAplayaForm;
        public static Admin_login LoginInstance { get; set; } = new Admin_login();
        public Lobby()
        {
            InitializeComponent();
        }
        private void LogoutButton_Click(object sender, EventArgs e)
        {
            this.Hide();

            if (Lobby.LoginInstance != null)
            {
                Lobby.LoginInstance.Show();
            }
            else
            {
                MessageBox.Show("Successfully logged out.");
            }
        }

        private void Lobby_Load(object sender, EventArgs e)
        {

        }

        private void branchesButton_Click(object sender, EventArgs e)
        {
            _branchesForm = new Branches(this);
            _branchesForm.Show();
            this.Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
