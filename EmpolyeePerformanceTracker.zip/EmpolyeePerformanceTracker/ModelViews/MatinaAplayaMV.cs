﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpolyeePerformanceTracker.Models;
using Microsoft.Data.SqlClient;

namespace EmpolyeePerformanceTracker.ModelViews
{
    internal class MatinaAplayaMV
    {
        private string connectionString;
        public List<MatinaAplayaModel> MatinaAplaya { get; set; } = new List<MatinaAplayaModel>();

        public MatinaAplayaMV()
        {
            // Assuming the connection string is stored in App.config
            connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            LoadMatinaAplaya();
        }

        public void LoadMatinaAplaya()
        {
            MatinaAplaya.Clear();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT id, EmployeeName, DaysWorked, DaysAbsent, TotalTimeSlackedOff, Grade FROM MatinaAplaya;";
                SqlCommand command = new SqlCommand(query, connection);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    MatinaAplayaModel matinaaplaya = new MatinaAplayaModel
                    {
                        id = reader.GetInt32(0),
                        EmployeeName = reader.GetString(1),
                        DaysWorked = reader.GetInt32(2),
                        DaysAbsent = reader.GetInt32(3),
                        TotalTimeSlacked = reader.GetString(4),
                        Grade = reader.GetString(5)

                    };
                    MatinaAplaya.Add(matinaaplaya);
                }
                connection.Close();
            }
        }
    }
}
