﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpolyeePerformanceTracker.Model;
using Microsoft.Data.SqlClient;

namespace EmpolyeePerformanceTracker.ModelViews
{
    internal class BagoAplayaMV
    {
        private string connectionString;
        public List<BagoAplayaModel> BagoAplaya1 { get; set; } = new List<BagoAplayaModel>();

        public BagoAplayaMV()
        {
            // Assuming the connection string is stored in App.config
            connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            LoadBagoAplaya1();
        }

        public void LoadBagoAplaya1()
        {
            BagoAplaya1.Clear();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT id, EmployeeName, DaysWorked, DaysAbsent, TotalTimeSlackedOff, Grade FROM BagoAplaya1;";
                SqlCommand command = new SqlCommand(query, connection);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    BagoAplayaModel bagoaplaya = new BagoAplayaModel
                    {
                        id = reader.GetInt32(0),
                        EmployeeName = reader.GetString(1),
                        DaysWorked = reader.GetInt32(2),
                        DaysAbsent = reader.GetInt32(3),
                        TotalTimeSlacked = reader.GetString(4),
                        Grade = reader.GetString(5)

                    };
                    BagoAplaya1.Add(bagoaplaya);
                }
                connection.Close();
            }
        }

        public void AddEmployee(BagoAplayaModel bagoaplaya)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO BagoAplaya1 (id, EmployeeName, DaysWorked, DaysAbsent, TotalTimeSlackedOff, Grade) VALUES (@id, @EmployeeName, @DaysWorked, @DaysAbsent, @TotalTimeSlackedOff, @Grade);";
                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("id", bagoaplaya.id);
                command.Parameters.AddWithValue("@EmployeeName", bagoaplaya.EmployeeName);
                command.Parameters.AddWithValue("@DaysWorked", bagoaplaya.DaysWorked);
                command.Parameters.AddWithValue("@DaysAbsent", bagoaplaya.DaysAbsent);
                command.Parameters.AddWithValue("@TotalTimeSlackedOff", bagoaplaya.TotalTimeSlacked);
                command.Parameters.AddWithValue("@Grade", bagoaplaya.Grade);

                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();

                LoadBagoAplaya1(); // Refresh the list after adding
            }
        }

        public void UpdateEmployee(BagoAplayaModel bagoaplaya)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "UPDATE BagoAplaya1 SET EmployeeName = @id, @EmployeeName, DaysWorked = @DaysWorked, DaysAbsent = @DaysAbsent, TotalTimeSlackedOff = @TotalTimeSlackedOff, Grade = @Grade WHERE id = @id";
                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@id", bagoaplaya.id);
                command.Parameters.AddWithValue("@EmployeeName", bagoaplaya.EmployeeName);
                command.Parameters.AddWithValue("@DaysWorked", bagoaplaya.DaysWorked);
                command.Parameters.AddWithValue("@DaysAbsent", bagoaplaya.DaysAbsent);
                command.Parameters.AddWithValue("@TotalTimeSlacked", bagoaplaya.TotalTimeSlacked);
                command.Parameters.AddWithValue("@Grade", bagoaplaya.Grade);

                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();

                LoadBagoAplaya1(); // Refresh the list after updating
            }
        }

        public void DeleteEmployee(int employeeId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM BagoAplaya1 WHERE id = @id;";
                SqlCommand command = new SqlCommand(query, connection);

                // Use parameterized query to prevent SQL Injection
                command.Parameters.AddWithValue("@id", employeeId);

                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();

                LoadBagoAplaya1();
            }
        }
    }
}


