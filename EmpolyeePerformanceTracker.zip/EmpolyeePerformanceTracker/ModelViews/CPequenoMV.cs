﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using EmpolyeePerformanceTracker.Model;
using EmpolyeePerformanceTracker.Models;
using Microsoft.Data.SqlClient;

namespace EmpolyeePerformanceTracker.ModelViews
{
    internal class CPequenoMV
    {
        private string connectionString;
        public List<CPequenoModel> CPequeno { get; set; } = new List<CPequenoModel>();

        public CPequenoMV()
        {
            // Assuming the connection string is stored in App.config
            connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            LoadCPequeno();
        }

        public void LoadCPequeno()
        {
            CPequeno.Clear();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT id, EmployeeName, DaysWorked, DaysAbsent, TotalTimeSlackedOff, Grade FROM CatalunanPeq;";
                SqlCommand command = new SqlCommand(query, connection);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    CPequenoModel cpequeno = new CPequenoModel
                    {
                        id = reader.GetInt32(0),
                        EmployeeName = reader.GetString(1),
                        DaysWorked = reader.GetInt32(2),
                        DaysAbsent = reader.GetInt32(3),
                        TotalTimeSlacked = reader.GetString(4),
                        Grade = reader.GetString(5)

                    };
                    CPequeno.Add(cpequeno);
                }
                connection.Close();
            }
        }
    }
}
