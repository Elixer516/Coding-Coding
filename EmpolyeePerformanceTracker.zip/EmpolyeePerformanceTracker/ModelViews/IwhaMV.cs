﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpolyeePerformanceTracker.Models;
using Microsoft.Data.SqlClient;

namespace EmpolyeePerformanceTracker.ModelViews
{
    internal class IwhaMV
    {
        private string connectionString;
        public List<IwhaModel> Iwha { get; set; } = new List<IwhaModel>();

        public IwhaMV()
        {
            // Assuming the connection string is stored in App.config
            connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            LoadIwha();
        }

        public void LoadIwha()
        {
            Iwha.Clear();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT id, EmployeeName, DaysWorked, DaysAbsent, TotalTimeSlackedOff, Grade FROM Iwha;";
                SqlCommand command = new SqlCommand(query, connection);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    IwhaModel iwha = new IwhaModel
                    {
                        id = reader.GetInt32(0),
                        EmployeeName = reader.GetString(1),
                        DaysWorked = reader.GetInt32(2),
                        DaysAbsent = reader.GetInt32(3),
                        TotalTimeSlacked = reader.GetString(4),
                        Grade = reader.GetString(5)

                    };
                    Iwha.Add(iwha);
                }
                connection.Close();
            }
        }
    }
}
