﻿using EmpolyeePerformanceTracker.Models;
using Microsoft.Data.SqlClient;
using System.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using EmpolyeePerformanceTracker.Model;

namespace EmpolyeePerformanceTracker.ModelViews
{
    internal class BangkalMV
    {
        private string connectionString;
        public List<BangkalModel> Bangkal { get; set; } = new List<BangkalModel>();

        public BangkalMV()
        {
            // Assuming the connection string is stored in App.config
            connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            LoadBangkal();
        }

        public void LoadBangkal()
        {
            Bangkal.Clear();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT id, EmployeeName, DaysWorked, DaysAbsent, TotalTimeSlackedOff, Grade FROM Bankal;";
                SqlCommand command = new SqlCommand(query, connection);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    BangkalModel student = new BangkalModel
                    {
                        id = reader.GetInt32(0),
                        EmployeeName = reader.GetString(1),
                        DaysWorked = reader.GetInt32(2),
                        DaysAbsent = reader.GetInt32(3),
                        TotalTimeSlacked = reader.GetString(4),
                        Grade = reader.GetString(5)
                    };
                    Bangkal.Add(student);
                }
                connection.Close();
            }
        }
    }
}
