﻿using EmpolyeePerformanceTracker.ModelViews;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmpolyeePerformanceTracker
{
    public partial class Bangkal : Form
    {
        private BangkalMV bangkalMV;
        private Branches _branchForm;
        public Bangkal(Branches branchForm)
        {
            InitializeComponent();
            _branchForm = branchForm;
            bangkalMV = new BangkalMV();
            LoadData();
        }
        private void LoadData()
        {
            DataGridViewBangkal.DataSource = null;
            DataGridViewBangkal.DataSource = bangkalMV.Bangkal;
        }

        private void returnButton_Click(object sender, EventArgs e)
        {
            _branchForm.Show();
            this.Close();
        }

        private void EmployeeList_Click(object sender, EventArgs e)
        {
            EmployeeList nextForm = new EmployeeList(_branchForm);
            nextForm.Show();
            this.Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
