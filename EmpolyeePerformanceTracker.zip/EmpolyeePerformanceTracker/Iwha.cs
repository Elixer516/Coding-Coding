﻿using EmpolyeePerformanceTracker.ModelViews;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmpolyeePerformanceTracker
{
    public partial class Iwha : Form
    {
        private IwhaMV iwhaMV;
        private Branches _branchForm;
        public Iwha(Branches branchForm)
        {
            InitializeComponent();
            _branchForm = branchForm;
            iwhaMV = new IwhaMV();
            LoadData();
        }

        private void LoadData()
        {
            DataGridViewIwha.DataSource = null;
            DataGridViewIwha.DataSource = iwhaMV.Iwha;
        }

        private void EmployeeList_Click(object sender, EventArgs e)
        {
            EmployeeList nextForm = new EmployeeList(_branchForm);
            nextForm.Show();
            this.Hide();
        }

        private void returnButton_Click(object sender, EventArgs e)
        {
            _branchForm.Show();
            this.Close();
        }

        private void DataGridViewIwha_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
