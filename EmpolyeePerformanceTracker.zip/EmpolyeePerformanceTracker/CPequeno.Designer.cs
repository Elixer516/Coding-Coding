﻿namespace EmpolyeePerformanceTracker
{
    partial class CPequeno
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            returnButton = new Button();
            DataGridViewCPequeno = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)DataGridViewCPequeno).BeginInit();
            SuspendLayout();
            // 
            // returnButton
            // 
            returnButton.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point);
            returnButton.Location = new Point(40, 31);
            returnButton.Margin = new Padding(3, 4, 3, 4);
            returnButton.Name = "returnButton";
            returnButton.Size = new Size(113, 39);
            returnButton.TabIndex = 8;
            returnButton.Text = "Return";
            returnButton.UseVisualStyleBackColor = true;
            returnButton.Click += returnButton_Click;
            // 
            // DataGridViewCPequeno
            // 
            DataGridViewCPequeno.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            DataGridViewCPequeno.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DataGridViewCPequeno.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataGridViewCPequeno.Location = new Point(40, 95);
            DataGridViewCPequeno.Name = "DataGridViewCPequeno";
            DataGridViewCPequeno.RowTemplate.Height = 28;
            DataGridViewCPequeno.Size = new Size(642, 221);
            DataGridViewCPequeno.TabIndex = 9;
            DataGridViewCPequeno.CellContentClick += DataGridViewCPequeno_CellContentClick;
            // 
            // CPequeno
            // 
            AutoScaleDimensions = new SizeF(8F, 19F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Orange;
            ClientSize = new Size(725, 433);
            Controls.Add(DataGridViewCPequeno);
            Controls.Add(returnButton);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Margin = new Padding(3, 4, 3, 4);
            Name = "CPequeno";
            Text = "CPequeno";
            ((System.ComponentModel.ISupportInitialize)DataGridViewCPequeno).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button returnButton;
        private DataGridView DataGridViewCPequeno;
    }
}