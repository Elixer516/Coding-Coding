﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmpolyeePerformanceTracker
{
    public partial class Branches : Form
    {
        private Lobby _LobbyForm;
        private BagoAplaya _bagoAplayaForm;
        private EmployeeList _employeeListForm;
        private Bangkal _bangkalForm;

        public Branches(Lobby lobbyForm)
        {
            InitializeComponent();
            _LobbyForm = lobbyForm;
        }

        private void returnButton_Click(object sender, EventArgs e)
        {
            this.Close();
            _LobbyForm.Show();
        }

        private void MatinaAplayaButton_Click(object sender, EventArgs e)
        {
            MatinaAplaya nextForm = new MatinaAplaya(this);
            nextForm.Show();
            this.Hide();
        }

        private void BagoAplayaButton_Click(object sender, EventArgs e)
        {
            BagoAplaya nextForm = new BagoAplaya(this);
            nextForm.Show();
            this.Hide();
        }

        private void Branches_Load(object sender, EventArgs e)
        {

        }

        private void bangkalButton_Click(object sender, EventArgs e)
        {
            Bangkal nextForm = new Bangkal(this);
            nextForm.Show();
            this.Hide();
        }

        private void iwhaButton_Click(object sender, EventArgs e)
        {
            Iwha nextForm = new Iwha(this);
            nextForm.Show();
            this.Hide();
        }

        private void PequenoButton_Click(object sender, EventArgs e)
        {
            CPequeno nextForm = new CPequeno(this);
            nextForm.Show();
            this.Hide();
        }
    }
}
