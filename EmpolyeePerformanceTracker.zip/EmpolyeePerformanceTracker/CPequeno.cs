﻿using EmpolyeePerformanceTracker.ModelViews;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmpolyeePerformanceTracker
{

    public partial class CPequeno : Form
    {
        private CPequenoMV cpequenoMV;
        private Branches _branchForm;
        public CPequeno(Branches branchForm)
        {
            InitializeComponent();
            _branchForm = branchForm;
            cpequenoMV = new CPequenoMV();
            LoadData();
        }
        private void LoadData()
        {
            DataGridViewCPequeno.DataSource = null;
            DataGridViewCPequeno.DataSource = cpequenoMV.CPequeno;
        }


        private void returnButton_Click(object sender, EventArgs e)
        {
            _branchForm.Show();
            this.Close();
        }

        private void EmployeeList_Click(object sender, EventArgs e)
        {
            EmployeeList nextForm = new EmployeeList(_branchForm);
            nextForm.Show();
            this.Hide();
        }

        private void DataGridViewCPequeno_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
