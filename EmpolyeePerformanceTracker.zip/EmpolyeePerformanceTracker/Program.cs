using System.Windows.Forms;

namespace EmpolyeePerformanceTracker
{
    internal static class Program
    {

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

                   Admin_login loginForm = new Admin_login();

            Lobby.LoginInstance = loginForm;

            Application.Run(loginForm);
        }
    }
}